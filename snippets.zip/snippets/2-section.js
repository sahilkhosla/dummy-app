// 1. 

function sayHi() {
  console.log('hi!');
}

var sayHello = function() {
  console.log('hello!');
}


// TODO: set a prop on sayHi to prove it's an object
// console.log('sayHi:', {sayHi});

// 1b.

// TODO: create a function expression and pass to caller
function caller(func) {
  if (typeof func === 'function') {
    func();
  } else {
    console.log('not a function!');
  }
}

// 2.

function createGame() {
  var negative = 0;
  var positive = 0;

  function getScore() {
    console.clear();
    console.log('Score: ' + (positive - negative));
  }

  function printScoreTable() {
    console.table({positive, negative, score: (positive - negative)});
  }

  function incrementScore() {
    positive++;
    getScore();
  }

  function decrementScore() {
    negative++;
    getScore();
  }

  window.onclick = function(e) {
    if (e.clientY <= 200) {
      decrementScore();
    } else {
      incrementScore();
    }
  }

  window.onkeypress = function(e) {
    if(e.key === 's') {
      printScoreTable();
    }
  }

}