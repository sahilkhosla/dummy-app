// 1.1

// demo window and this
alert('hello!');

console.log('window:', window)
console.log('this:', this)

console.log(window === this);


// demo where global variables and functions reside
var a = 'foo';

function b() {
  console.log('I am b!')
}

console.log(a);
b();

// ------------------------

// 1.2

// TODO: move 33/34 to the top 
// hoisting variable
// hoisting function

var a = 'foo';

function b() {
  console.log('I am b!')
}

console.log(a);
b();

// ------------------------

// 1.3

var color = 'red';

function first() {
  var color = 'green';
  console.log(color);
}

first();
console.log(color);

// ------------------------

// 1.4

// TODO add second function and invoke from first