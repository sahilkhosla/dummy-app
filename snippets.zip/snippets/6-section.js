
'---------------------'
// revealing module pattern
'---------------------'

var counter = (function() {
  // private
  var count = 0;

  function log() {
    console.log(count);
  }

  // public
  function incrementCount() {
    count++;
    log();
  }

  function decrementCount() {
    count--;
    log();
  }

  function getCount() {
    return count
  }

  // TODO reveal methods  

})();

'---------------------'
// ES6 import/export
'---------------------'

// go src/index src/util and src/greet

'---------------------'
// singleton pattern
'---------------------'

const db = (() => {
  // "state"
  let connection = '';

  const connect = () => {
    // TODO convert to singleton
    console.log('connecting...');
    connection = `sql.db [${Math.floor(Math.random() * 100)}]`;
    return connection;
  }

  const terminate = () => {
    if (connection) {
      console.log('terminating connection...');
      connection = '';
    } else {
      console.log('no existing connection!');
    }
    
  }

  const getDB = () => {
    return connect();
  }

  const termDB = () => {
    return terminate();
  }

  return {
    getDB,
    termDB
  }

})();

'---------------------'
// facade pattern - xx
'---------------------'

function TravelAgent(options) {
  this.type = options.type;
  this.flight = new Flight();
  this.hotel = new Hotel();
}

TravelAgent.prototype.book = function(bookingInfo) {

  const {hotelId, flightNumber} = bookingInfo;

  console.log(this)

  switch (this.type) {
    case 'Flight':
      this.flight.book(flightNumber);
      break;
    case 'Hotel':
      this.hotel.book(hotelId);
      break;
    case 'Package':
      this.flight.book(flightNumber);
      this.hotel.book(hotelId);
      break;
    default:
      throw Error(`Error: type not supported ${this.type}`);
  }
}

function Flight() {
  function book(flightNumber) {      
    console.log(`booking flight ${flightNumber}`);
  }

  return {
    book
  }
}

function Hotel() {
  function book(hotelId) {
    console.log(`booking hotel ${hotelId}`);
  }

  return {
    book
  }
}

// TODO book a flight and a package
